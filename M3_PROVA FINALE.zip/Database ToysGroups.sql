/* Task 2: Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare 
lo scenario proposto tramite la sintassi DDL. Implementa fisicamente le tabelle utilizzando 
il DBMS SQL Server(o altro).
*/

CREATE SCHEMA ToysGroups; 
USE ToysGroups;
-- Creazione del Database 'ToysGroups' e sua esecuzione

CREATE TABLE Category (
    CategoryID INT NOT NULL,
	CategoryName VARCHAR(50),
CONSTRAINT PK_CategoryID PRIMARY KEY(CategoryID)
);
-- Creazione Tabella Parent 'Category'

CREATE TABLE Product (
    ProductID INT NOT NULL,
	ProductName VARCHAR(80),
    Price DECIMAL(10,2),
    CategoryID INT NOT NULL,
CONSTRAINT PK_ProductID PRIMARY KEY(ProductID),
CONSTRAINT FK_CategoryID FOREIGN KEY(CategoryID)
REFERENCES Category(CategoryID)
);
-- Creazione Tabella Child 'Product' della Tabella Parent 'Category'

CREATE TABLE Region (
    RegionID INT NOT NULL,
	RegionName VARCHAR(200),
CONSTRAINT PK_RegionID PRIMARY KEY(RegionID)
);
-- Creazione Tabella Parent 'Region'

CREATE TABLE Sales (
    SalesID INT,
	SalesDate DATE,
    SalesQuantity INT,
    ProductID INT NOT NULL,
    RegionID INT NOT NULL,
CONSTRAINT PK_SalesID PRIMARY KEY(SalesID),
CONSTRAINT FK_ProductID FOREIGN KEY(ProductID)
REFERENCES Product(ProductID),
CONSTRAINT FK_RegionID FOREIGN KEY(RegionID) 
REFERENCES Region(RegionID)
);
-- Creazione Tabella Child 'Sales' delle due Tabelle Parent 'Product' e 'Region'

CREATE TABLE Country (
    CountryID INT NOT NULL,
	CountryName VARCHAR(100),
    RegionID INT NOT NULL,
CONSTRAINT PK_CountryID PRIMARY KEY(CountryID),
CONSTRAINT FK_Country_RegionID FOREIGN KEY(RegionID)
REFERENCES Region(RegionID)
);
-- Creazione Tabella Child 'Country' della Tabella Parent 'Region'

/* Task 3: Popola le tabelle utilizzando dati a tua discrezione 
(sono sufficienti pochi record per tabella; riporta le query utilizzate)
*/

INSERT INTO Region (RegionID, RegionName) 
VALUES
(1, 'North America'),
(2, 'South America'),
(3, 'Europe'),
(4, 'Asia');

SELECT *
FROM Region;
-- Popolamento della Tabella 'Region' con verifica annessa

INSERT INTO Category (CategoryID, CategoryName) 
VALUES
(1, 'Creative Play'),
(2, 'Outdoor Activities'),
(3, 'Family Games'),
(4, 'Collectible Figures'),
(5, 'Crafting Supplies'),
(6, 'Learning Tools'),
(7, 'Plush Companions'),
(8, 'Toy Vehicles'),
(9, 'Construction Toys'),
(10, 'Pool Fun');

SELECT *
FROM Category;
-- Popolamento della Tabella 'Category' con verifica annessa

INSERT INTO Product (ProductID, ProductName, Price, CategoryID) 
VALUES
(1, 'Soccer Ball', 105.36, 5),
(2, 'Scooter', 204.44, 2),
(3, 'Basketball', 152.95, 4),
(4, 'Action Figure', 276.29, 2),
(5, 'Puzzle', 138.00, 1),
(6, 'Board Game', 78.14, 3),
(7, 'Outdoor Tent', 85.50, 4),
(8, 'Toy Train', 30.60, 3),
(9, 'Doll House', 112.89, 1),
(10, 'Construction Set', 95.70, 2),
(11, 'Remote Control Car', 55.35, 5),
(12, 'Stuffed Animal', 25.99, 1),
(13, 'Frisbee', 20.50, 5),
(14, 'Jump Rope', 15.00, 4),
(15, 'Kite', 12.75, 3),
(16, 'Model Airplane', 45.90, 5),
(17, 'Skateboard', 75.25, 2),
(18, 'Tennis Racket', 100.00, 4),
(19, 'Bicycle', 250.00, 1),
(20, 'Beach Ball', 10.00, 5),
(21, 'Hula Hoop', 22.00, 4),
(22, 'Teddy Bear', 30.50, 1),
(23, 'Remote Control Boat', 60.00, 5),
(24, 'Magic Set', 45.00, 3),
(25, 'Bouncy Ball', 5.00, 4),
(26, 'Water Gun', 15.50, 3),
(27, 'Catapult Toy', 35.00, 1),
(28, 'Puzzle Box', 25.99, 2),
(29, 'Dart Board', 60.00, 4),
(30, 'Bow and Arrow Set', 45.00, 3),
(31, 'Toy Robot', 55.00, 1),
(32, 'Marbles', 10.00, 2),
(33, 'Play-Doh Set', 20.00, 5),
(34, 'Crayons Set', 5.00, 4),
(35, 'Finger Paints', 10.50, 3),
(36, 'Action Figure Set', 150.00, 2),
(37, 'Toy Fire Truck', 40.00, 1),
(38, 'Musical Instruments Set', 80.00, 5),
(39, 'Train Set', 100.00, 4),
(40, 'Remote Control Helicopter', 120.00, 3),
(41, 'Scooter with Lights', 85.00, 2),
(42, 'Animal Puzzle', 30.00, 1),
(43, 'Jigsaw Puzzle', 20.00, 5),
(44, 'Toy Laptop', 70.00, 4),
(45, 'Magic Marker Set', 10.00, 3),
(46, 'Kids Telescope', 25.00, 2),
(47, 'Kids Binoculars', 35.00, 1),
(48, 'Kids Camera', 50.00, 5),
(49, 'Plush Dinosaur', 20.00, 4),
(50, 'Stuffed Unicorn', 25.00, 1),
(51, 'Toy Chain Saw', 30.00, 2),
(52, 'Kid-Safe Knife Set', 45.00, 3),
(53, 'Gardening Set for Kids', 30.00, 4),
(54, 'Kids Hammer', 10.00, 1),
(55, 'Kids Toolbox', 60.00, 5),
(56, 'Airplane Toy', 20.00, 2),
(57, 'Paddle Ball', 10.00, 3),
(58, 'Sailing Boat', 25.00, 4),
(59, 'Fire Truck Toy', 30.00, 1),
(60, 'Car Track Set', 100.00, 5),
(61, 'Wooden Train Set', 80.00, 2),
(62, 'Kids Sewing Kit', 20.00, 3),
(63, 'Kids Drawing Set', 25.00, 1),
(64, 'Kids DIY Kit', 40.00, 5),
(65, 'Kids Gardening Set', 30.00, 2),
(66, 'Animal Masks', 20.00, 4),
(67, 'Animal Costumes', 50.00, 3),
(68, 'Magic Wand', 15.00, 1),
(69, 'Knights Costume', 40.00, 5),
(70, 'Fairy Wings', 25.00, 2),
(71, 'Dragon Hat', 15.00, 3),
(72, 'Juggling Balls', 20.00, 4),
(73, 'Dinosaur Figures', 35.00, 1),
(74, 'Kids Yoga Mat', 30.00, 5),
(75, 'Kids Resistance Bands', 20.00, 2),
(76, 'Beach Tent', 80.00, 3),
(77, 'Kids Sunglasses', 10.00, 4),
(78, 'Kids Baseball Mitt', 30.00, 1),
(79, 'Kids Soccer Goal', 45.00, 5),
(80, 'Kids Baseball Bat', 25.00, 2),
(81, 'Kids Basketball Hoop', 100.00, 3),
(82, 'Kids Roller Skates', 75.00, 4),
(83, 'Kids Skating Board', 60.00, 1),
(84, 'Kids Swing', 150.00, 5),
(85, 'Kids Trampoline', 200.00, 2),
(86, 'Kids Slide', 120.00, 3),
(87, 'Kids Playhouse', 300.00, 4),
(88, 'Kids Sandpit', 150.00, 1),
(89, 'Kids Water Slide', 100.00, 5),
(90, 'Kids Bicycle Helmet', 40.00, 2),
(91, 'Kids Skateboard Helmet', 40.00, 3),
(92, 'Kids Safety Gear Set', 50.00, 4),
(93, 'Kids Soccer Cleats', 60.00, 1),
(94, 'Kids Basketball Shoes', 70.00, 5),
(95, 'Kids Baseball Cleats', 55.00, 2),
(96, 'Kids Swim Goggles', 20.00, 3),
(97, 'Kids Swim Flippers', 25.00, 4),
(98, 'Kids Life Jacket', 30.00, 1),
(99, 'Kids Pool Noodles', 10.00, 5),
(100, 'Kids Beach Ball', 5.00, 2);

SELECT *
FROM Product;
-- Popolamento della Tabella 'Product' con verifica annessa

INSERT INTO Sales (SalesID, SalesDate, SalesQuantity, ProductID, RegionID) 
VALUES
(1, '2020-01-15', 3, 1, 1),
(2, '2020-02-20', 2, 1, 1),
(3, '2020-03-25', 1, 2, 1),
(4, '2020-04-10', 5, 2, 2),
(5, '2020-05-05', 7, 3, 2),
(6, '2021-01-01', 4, 1, 3),
(7, '2021-02-15', 2, 1, 3),
(8, '2021-03-18', 3, 2, 3),
(9, '2021-04-25', 6, 3, 1),
(10, '2021-05-30', 1, 4, 1),
(11, '2022-01-22', 4, 2, 2),
(12, '2022-02-12', 5, 2, 2),
(13, '2022-03-09', 2, 3, 3),
(14, '2022-04-28', 8, 3, 3),
(15, '2022-05-15', 10, 4, 4),
(16, '2023-06-14', 3, 1, 4),
(17, '2023-07-18', 2, 4, 1),
(18, '2023-08-24', 4, 1, 1),
(19, '2023-09-30', 5, 2, 2),
(20, '2023-10-12', 1, 3, 2),
(21, '2024-01-15', 6, 1, 3),
(22, '2024-02-20', 2, 2, 3),
(23, '2024-03-25', 1, 3, 4),
(24, '2024-04-10', 3, 4, 4),
(25, '2024-05-05', 7, 1, 1),
(26, '2024-06-01', 4, 1, 1),
(27, '2024-07-15', 2, 2, 2),
(28, '2024-08-20', 3, 2, 2),
(29, '2024-09-25', 6, 3, 3),
(30, '2024-10-30', 1, 4, 3),
(31, '2024-01-22', 4, 2, 4),
(32, '2024-02-12', 5, 3, 4),
(33, '2024-03-09', 2, 4, 1),
(34, '2024-04-28', 8, 1, 1),
(35, '2024-05-15', 10, 2, 2),
(36, '2024-06-14', 3, 3, 3),
(37, '2024-07-18', 2, 4, 3),
(38, '2024-08-24', 4, 1, 4),
(39, '2024-09-30', 5, 2, 4),
(40, '2024-10-12', 1, 3, 1),
(41, '2024-01-15', 6, 4, 1),
(42, '2024-02-20', 2, 1, 1),
(43, '2024-03-25', 1, 2, 2),
(44, '2024-04-10', 3, 3, 2),
(45, '2024-05-05', 7, 4, 3),
(46, '2024-06-01', 4, 1, 3),
(47, '2024-07-15', 2, 2, 4),
(48, '2024-08-20', 3, 3, 4),
(49, '2024-09-25', 6, 4, 1),
(50, '2024-10-30', 1, 1, 1),
(51, '2024-01-22', 4, 2, 2),
(52, '2024-02-12', 5, 3, 2),
(53, '2024-03-09', 2, 4, 3),
(54, '2024-04-28', 8, 1, 3),
(55, '2024-05-15', 10, 2, 4),
(56, '2024-06-14', 3, 3, 4),
(57, '2024-07-18', 2, 4, 1),
(58, '2024-08-24', 4, 1, 1),
(59, '2024-09-30', 5, 2, 2),
(60, '2024-10-12', 1, 3, 2),
(61, '2024-01-15', 6, 4, 3),
(62, '2024-02-20', 2, 1, 3),
(63, '2024-03-25', 1, 2, 4),
(64, '2024-04-10', 3, 3, 4),
(65, '2024-05-05', 7, 1, 1),
(66, '2024-06-01', 4, 1, 1),
(67, '2024-07-15', 2, 2, 2),
(68, '2024-08-20', 3, 2, 2),
(69, '2024-09-25', 6, 3, 3),
(70, '2024-10-30', 1, 4, 3),
(71, '2024-01-22', 4, 2, 4),
(72, '2024-02-12', 5, 3, 4),
(73, '2024-03-09', 2, 4, 1),
(74, '2024-04-28', 8, 1, 1),
(75, '2024-05-15', 10, 2, 2),
(76, '2024-06-14', 3, 3, 3),
(77, '2024-07-18', 2, 4, 3),
(78, '2024-08-24', 4, 1, 4),
(79, '2024-09-30', 5, 2, 4),
(80, '2024-10-12', 1, 3, 1),
(81, '2024-01-15', 6, 4, 1),
(82, '2024-02-20', 2, 1, 1),
(83, '2024-03-25', 1, 2, 2),
(84, '2024-04-10', 3, 3, 2),
(85, '2024-05-05', 7, 4, 3),
(86, '2024-06-01', 4, 1, 3),
(87, '2024-07-15', 2, 2, 4),
(88, '2024-08-20', 3, 3, 4),
(89, '2024-09-25', 6, 4, 1),
(90, '2024-10-30', 1, 1, 1),
(91, '2024-01-22', 4, 2, 2),
(92, '2024-02-12', 5, 3, 2),
(93, '2024-03-09', 2, 4, 3),
(94, '2024-04-28', 8, 1, 3),
(95, '2024-05-15', 10, 2, 4),
(96, '2024-06-14', 3, 3, 4),
(97, '2024-07-18', 2, 4, 1),
(98, '2024-08-24', 4, 1, 1),
(99, '2024-09-30', 5, 2, 2),
(100, '2024-10-12', 1, 3, 2);

SELECT *
FROM Sales;
-- Popolamento della Tabella 'Sales' con verifica annessa

INSERT INTO Country (CountryID, CountryName, RegionID) VALUES
(1, 'Argentina', 2),
(2, 'Brazil', 2),
(3, 'Chile', 2),
(4, 'Mexico', 1),
(5, 'United States', 1),
(6, 'Canada', 1),
(7, 'Germany', 3),
(8, 'France', 3),
(9, 'United Kingdom', 3),
(10, 'Italy', 3),
(11, 'Spain', 3),
(12, 'Portugal', 3),
(13, 'South Korea', 4),
(14, 'Japan', 4),
(15, 'Singapore', 4),
(16, 'Malaysia', 4),
(17, 'Thailand', 4),
(18, 'India', 4),
(19, 'Turkey', 4),
(20, 'Taiwan', 4),
(21, 'Israel', 4),
(22, 'Saudi Arabia', 4),
(23, 'United Arab Emirates', 4),
(24, 'Egypt', 2),
(25, 'South Africa', 2),
(26, 'Colombia', 2),
(27, 'Peru', 2),
(28, 'Philippines', 4),
(29, 'Vietnam', 4),
(30, 'Morocco', 2),
(31, 'Jordan', 4),
(32, 'Mexico', 1),
(33, 'Slovakia', 3),
(34, 'Czech Republic', 3),
(35, 'Hungary', 3),
(36, 'Romania', 3),
(37, 'Bulgaria', 3),
(38, 'Lithuania', 3),
(39, 'Latvia', 3),
(40, 'Estonia', 3),
(41, 'Greece', 3),
(42, 'Croatia', 3),
(43, 'Serbia', 3),
(44, 'Montenegro', 3),
(45, 'Bosnia and Herzegovina', 3),
(46, 'Albania', 3),
(47, 'North Macedonia', 3),
(48, 'Georgia', 4),
(49, 'Armenia', 4),
(50, 'Azerbaijan', 4);

SELECT *
FROM Country;
-- Popolamento della Tabella 'Country' con verifica annessa

/*Task 4: Dopo aver popolate le tabelle, scrivi delle query utili a:
1)	Verificare che i campi definiti come PK siano univoci. In altre parole, 
scrivi una query per determinare l’univocità dei valori di ciascuna PK 
(una query per tabella implementata).
*/

SELECT CategoryID,
      COUNT(*) PK_univoca
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

SHOW KEYS
FROM Category;
-- La PK di Category è univoca, (in alternativa SHOW KEYS). La stessa query viene ripetuta per le altre Tab

SELECT ProductID,
      COUNT(*) PK_univoca
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

SHOW KEYS
FROM Product;

SELECT RegionID,
      COUNT(*) PK_univoca
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

SHOW KEYS
FROM Region;

SELECT SalesID,
      COUNT(*) PK_univoca
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;

SHOW KEYS
FROM Sales;

SELECT CountryID,
      COUNT(*) PK_univoca
FROM Country
GROUP BY CountryID
HAVING COUNT(*) > 1;

SHOW KEYS
FROM Country;

/* 2)	Esporre l’elenco delle transazioni indicando nel result set 
il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato 
in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno 
(>180 -> True, <= 180 -> False).
*/

SELECT s.SalesID 'Codice documento',
       s.SalesDate 'Data',
       p.ProductName 'Nome prodotto',
       c.CategoryName 'Categoria prodotto',
       cnt.CountryName 'Nazione',
       r.RegionName 'Regione',
 CASE
     WHEN DATEDIFF(CURDATE(), s.SalesDate) > 180 THEN 'TRUE'
     WHEN DATEDIFF(CURDATE(), s.SalesDate) <= 180 THEN 'FALSE'
END  'CHECK VENDITE'
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
JOIN Country cnt ON s.RegionID = cnt.RegionID
JOIN Region r ON cnt.RegionID = r.RegionID;

/* 3)	Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore 
della media delle vendite realizzate nell’ultimo anno censito. (ogni valore della condizione 
deve risultare da una query e non deve essere inserito a mano). Nel result set devono comparire 
solo il codice prodotto e il totale venduto.
*/

SELECT s.ProductID 'Codice prodotto',
       SUM(SalesQuantity) 'Totale venduto',
       s.SalesDate
FROM Sales s
WHERE s.SalesDate >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR) -- Vendite dell'ultimo anno
GROUP BY s.ProductID, s.SalesDate
HAVING SUM(SalesQuantity) > (SELECT AVG(SalesQuantity)
							 FROM Sales
							 WHERE SalesDate >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
);  

/* 4)	Esporre l’elenco dei soli prodotti venduti e per ognuno di questi 
il fatturato totale per anno.
*/

SELECT s.ProductID 'Codice prodotto',
       p.ProductName,
       SUM(s.SalesQuantity * p.Price) 'Totale fatturato',
       YEAR(s.SalesDate) 'Anno'
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
GROUP BY s.ProductID, YEAR(s.SalesDate);

/* 5)	Esporre il fatturato totale per stato per anno. Ordina il risultato 
per data e per fatturato decrescente.
*/

SELECT YEAR(s.SalesDate) 'Anno',
	   cnt.CountryName 'Stato',
       SUM(s.SalesQuantity * p.Price) 'Totale fatturato'
FROM Sales s
JOIN Country cnt ON s.RegionID = cnt.RegionID
JOIN Product p ON s.ProductID = p.ProductID
GROUP BY YEAR(s.SalesDate), cnt.CountryName
ORDER BY YEAR(s.SalesDate) ASC, 'Totale fatturato' DESC;

/* 6)	Rispondere alla seguente domanda: qual è la categoria di articoli 
maggiormente richiesta dal mercato?
*/

SELECT c.CategoryName 'Categoria',
       SUM(s.SalesQuantity) 'Totale vendite'
FROM Sales s 
JOIN Product p ON s.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
GROUP BY c.CategoryName
ORDER BY 'Totale vendite' DESC
LIMIT 1;

/* 7)	Rispondere alla seguente domanda: quali sono i prodotti invenduti? 
Proponi due approcci risolutivi differenti.
*/

-- Primo approccio
SELECT p.ProductID 'Cod prodotto',
       p.ProductName 'Nome prodotto'
FROM Product p 
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.ProductID IS NULL;

-- Secondo approccio
SELECT p.ProductID 'Cod prodotto',
       p.ProductName 'Nome prodotto'
FROM Product p
WHERE p.ProductID NOT IN (SELECT s.ProductID
						  FROM Sales s);
        
/* 8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” 
delle informazioni utili (codice prodotto, nome prodotto, nome categoria).
*/

CREATE VIEW vw_ProdottiDenormalizzati AS
SELECT p.ProductID 'Cod prodotto',
       p.ProductName 'Nome prodotto',
       c.CategoryName 'Categoria'
FROM Product p
JOIN Category c ON p.CategoryID = c.CategoryID;

/* 9)	Creare una vista per le informazioni geografiche.
*/

CREATE VIEW vw_InfoGeografiche AS
SELECT r.RegionID 'Cod Regione',
       cnt.CountryID 'Cod Stato',
       r.RegionName 'Nome Regione',
       cnt.CountryName 'Nome Stato'
FROM Region r 
JOIN Country cnt ON r.RegionID = cnt.RegionID;